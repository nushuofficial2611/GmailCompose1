import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailCompose {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sowmy\\Downloads\\chromedriver.exe") ;
		WebDriver driver = new ChromeDriver();
		driver.get("https://gmail.com");
		driver.findElement(By.xpath("//input[@aria-label=\"Email or phone\"]")).sendKeys("bhavanadummy2611");
	    driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type=\"password\"]")).sendKeys("Dummy@2611");
		driver.findElement(By.xpath("//*[text()='Next']")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//div[@class='T-I T-I-KE L3']")).click();
		driver.findElement(By.xpath("//*[@name=\"to\"]")).sendKeys("Hello@Hello.com");
		driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys("Incubyte");
		driver.findElement(By.xpath("//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']")).sendKeys("Automation QA test for Incubyte");
	}

}
